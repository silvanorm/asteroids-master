const logoutBtn = document.getElementById("logoutBtn");

logoutBtn.onclick = function(evt) {
    evt.preventDefault();
    // sessionStorage.removeItem("token");
    sessionStorage.clear();
}
