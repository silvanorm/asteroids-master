# asteroids
Asteroids inspired technical test for candidates applying to an internship at Bloom Games.

If you are a candidate, [head to the Wiki](https://github.com/bloomstudios/asteroids/wiki) for instructions.
If you have questions, [raise an issue](https://github.com/bloomstudios/asteroids/issues/new).
